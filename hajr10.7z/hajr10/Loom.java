package hajr10;

public class Loom {
    
    protected String sugu; 
    
    public void toit(){
        System.out.println("Söön kõike");
    }
    
    public void temp(){
        System.out.println("püsisoojane");
    }
    
    public String getSugu() {
        return sugu;
    }

    public void setSugu(String sugu) {
        this.sugu = sugu;
    }

}
