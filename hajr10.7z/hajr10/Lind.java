package hajr10;

public class Lind extends Loom {
    private boolean lendabHästi;

    public Lind(boolean lendabHästi) {
        this.lendabHästi = lendabHästi;
    }

    public boolean isLendabHästi() {
        return lendabHästi;
    }
}
