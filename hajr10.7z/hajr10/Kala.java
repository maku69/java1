package hajr10;

public class Kala extends Loom {
    private boolean elabVees;

    public Kala(boolean elabVees) {
        this.elabVees = elabVees;
    }

    public boolean isElabVees() {
        return elabVees;
    }
}
