public class main {
    public static void main(String[] args) {
        // loome kaks Ese objekti
        Ese ese1 = new Ese("Laud", "Puit", 120);
        Ese ese2 = new Ese("Tool", "Metall", 80);

        // kutsume välja nende tegevused
        ese1.kysiAndmed();
        ese2.kysiAndmed();

        ese1.teeMingiArvutus();
        ese2.muudaSuurust(100);
    }
}
