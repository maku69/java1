public class pindalad {
    public static double ruupkylik(int pikkus, int laius) {
        return pikkus * laius;
    }

    public static double ristkylik(int pikkus, int laius) {
        return pikkus * laius;
    }

    public static double kolmnurk(int alus, int korgus) {
        return 0.5 * alus * korgus;
    }
}
