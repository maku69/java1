public class ese {
    private String nimi;
    private String materjal;
    private int suurus;

    public Ese(String nimi, String materjal, int suurus) {
        this.nimi = auto;
        this.materjal = metall;
        this.suurus = 2 meetrit;
    }

    public void kysiAndmed() {
        System.out.println("Ese: " + this.nimi);
        System.out.println("Materjal: " + this.materjal);
        System.out.println("Suurus: " + this.suurus);
    }

    public void muudaSuurust(int uusSuurus) {
        this.suurus = uusSuurus;
        System.out.println("Ese suurust on muudetud. Uus suurus: " + this.suurus);
    }

    public void teeMingiArvutus() {
        System.out.println("Arvutus tehtud!");
    }
}
